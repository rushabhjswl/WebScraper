const mongoose = require('mongoose');

let productSchema = new mongoose.Schema({
    productTitle : String,
    productPrice : String,
    productLink : String,
    productImageLink : String,
    productSite : String
});

//creating index on productTitle field.
productSchema.index({productTitle : 'text'});
let Products = mongoose.model('Products', productSchema);

module.exports = Products;