const express = require('express');
const router = express.Router();
const products = require('../controllers/server');

router.get('/', function(req, res){
   products.index(req,res);
});


 router.post("/getData", (request, response)=>{
    console.log('In routes ' + request.body.name);
    products.getData(request, response);
    //products.push(product)
    //response.render('products',{products});
 });

 module.exports = router;